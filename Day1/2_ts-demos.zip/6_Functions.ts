// Function Declaration
// function hello() {
//     console.log("Hello World!");
// }

// hello();

// Function Expression
// const hello = function () {
//     console.log("Hello World!");
// };

// hello();
// console.log(hello);
// var r1 = hello();
// console.log(r1);
// console.log(typeof r1);

// var r1: undefined;
// // r1 = 10;    // Error
// r1 = undefined;
// console.log(r1);

// var r2: void;
// // r2 = 10;    // Error
// r2 = undefined;
// console.log(r2);

// var r3: never;
// // r3 = 10;    // Error
// // r3 = undefined; // Error
// console.log(r3);

// var f1 = (function () {

// });

// var f2 = (function () {
//     return 10;
// });

// var f3 = (function () {
//     throw new Error("Test");
// });

// ---------------------------------------------

function add1(x: number, y: number): number {
    return x + y;
}

let add2 = function (x: number, y: number): number {
    return x + y;
}

// let add3;
// add3 = 10;
// let add3: () => void;
let add3: (a: number, b: number) => number;
add3 = function (x: number, y: number): number {
    return x + y;
}

// let j: number;
// j = 10;

let add4: (a: number, b: number) => number;
add4 = function (x, y) {
    return x + y;
}

// Lamdas
let add5: (a: number, b: number) => number;
add5 = (x, y) => {
    return x + y;
}

// Single Line Lambda
let add6: (a: number, b: number) => number;
add6 = (x, y) => x + y;

console.log(add1(2, 3));
console.log(add2(2, 3));
console.log(add3(2, 3));
console.log(add4(2, 3));
console.log(add5(2, 3));
console.log(add6(2, 3));