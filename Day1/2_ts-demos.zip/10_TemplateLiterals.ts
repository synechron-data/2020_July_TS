// var d1 = "Hello";
// var d2 = 'Hello';
// var d3 = `Hello`;

// console.log(d1);
// console.log(typeof d1);

// console.log(d2);
// console.log(typeof d2);

// console.log(d3);
// console.log(typeof d3);

// var d4 = "H\n\te\n\t\tl\n\t\t\tl\n\t\t\t\to";
// console.log(d4);

// var d5 = `H
//     e
//         l
//             l
//                 o`;
// console.log(d5);

var fname = "Manish";
var lname = "Sharma";

var message1 = "Hello, " + fname + " " + lname;
console.log(message1);

var message2 = `Hello, ${fname} ${lname}`;
console.log(message2);

var message3 = `Hello, ${fname.toUpperCase()} ${lname.toUpperCase()}`;
console.log(message3);