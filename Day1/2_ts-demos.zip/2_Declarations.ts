// Implicitly Typed

// var data = 10;
// data = "ABC";        // Error

// var data = "ABC";
// data = 10;           // Error

// var data;
// data = "ABC";
// data = 10;

// Explicitly Typed

// var age: number;
// age = 10;
// age = "ABC";         // Error

// var s: symbol = Symbol("Hello");

// number / string / boolean / undefined / Array / Object / Date / RegExp / function / void
// Based on target section configured in tsconfig.json
// Based on lib section configured in tsconfig.json

// any / never / Tuple / Enum / Interface / Class

// Method to add 2 numbers
function add(x: number, y: number) {
    return x + y;
}

console.log(add(2, 3));
// console.log(add(2, "ABC"));
// console.log(add("ABC", "XYZ"));