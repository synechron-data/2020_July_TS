// const env;      // Error - 'const' declarations must be initialized

// const env = "production";
// console.log(env);

// // env = "development";    // Error - Cannot assign to 'env' because it is a constant.
// // console.log(env);

// if (true) {
//     const env = "development";          // new block scoped variable is created
//     console.log(env);
// }

const obj = { id: 1 };
console.log(obj);
obj.id = 100;
// obj = { name: "Manish" };   // Error - Cannot assign to 'obj' because it is a constant.
console.log(obj);