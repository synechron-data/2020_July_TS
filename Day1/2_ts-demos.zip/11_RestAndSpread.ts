// In ECMASCript, Array Rest and Spread, came in ECMAScript 2015
// In ECMASCript, Object Rest and Spread, came in ECMAScript 2018

// ... Left (Rest) = ... Right (Spread)
// ------------------------------------------------------------------- Array Spread
// var numArr1 = [10, 20, 30, 40, 50];

// var numArr2 = numArr1;
// var numArr2 = numArr1.slice();
// var numArr2 = [].concat(numArr1);
// var numArr2 = [...numArr1];

// numArr2[0] = 1000;

// console.log(`numArr1 - ${numArr1}`);
// console.log(`numArr2 - ${numArr2}`);

// var numArr1 = [10, 20];
// var numArr2 = [30, 40, 50];

// var numArr3 = numArr1.concat(numArr2);
// var numArr3 = [].concat(numArr1, numArr2);
// var numArr3 = [...numArr1, ...numArr2];

// console.log(`numArr1 - ${numArr1}`);
// console.log(`numArr2 - ${numArr2}`);
// console.log(`numArr3 - ${numArr3}`);

// ------------------------------------------------------------------- Array Destructing and Rest
// var numArr1 = [10, 20, 30, 40, 50];

// // Array Destructuring
// // var x = numArr1[0];
// // var y = numArr1[2];

// // var [x, , y] = numArr1;

// // Array Destructuring with Rest
// var [x, y, ...z] = numArr1;

// console.log(`x - ${x}`);
// console.log(`y - ${y}`);
// console.log(`z - ${z}`);

// ------------------------------------------------------------------- Object Spread
// var emp1 = { id: 1, name: "Manish", address: { city: "Pune" } };

// // var emp2 = emp1;

// // Shallow Copy
// // var emp2 = Object.assign({}, emp1);
// // var emp2 = { ...emp1 };

// // Deep Copy
// var emp2 = JSON.parse(JSON.stringify(emp1));

// emp2.id = 1000;
// emp2.address.city = "Mumbai";

// console.log(`emp1 - ${JSON.stringify(emp1)}`);
// console.log(`emp2 - ${JSON.stringify(emp2)}`);

// ------------------------------------------------------------------- Object Destructing and Rest
var emp = { id: 1, ename: "Manish", city: "Pune", state: "MH", pin: 411021 };

// Object Destructuring
// var id = emp.id;
// var ename = emp.ename;

// var { id, ename } = emp;

// Object Destructuring with Rest
var { id, ename, ...address } = emp;

console.log(`Id: ${id}`);
console.log(`Name: ${ename}`);
console.log(`Address: ${JSON.stringify(address)}`);