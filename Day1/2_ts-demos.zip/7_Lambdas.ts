// Lambdas as Callback

var employees = [
    { id: 1, name: "ABC", city: "Pune" },
    { id: 2, name: "XYZ", city: "Mumbai" },
    { id: 3, name: "PQR", city: "Pune" }
];

// ----------------------------------------------
// var pune_employees = [];

function filterFn(item: any): boolean {
    return item.city === "Pune";
}

// for (let i = 0; i < employees.length; i++) {
//     if (filterFn(employees[i]))
//         pune_employees.push(employees[i]);
// }

// console.log(pune_employees);

// ---------------------------------------------

// function filterFn(item: any) {
//     return item.city === "Pune";
// }

// var pune_employees = employees.filter(filterFn);

// console.log(pune_employees);

// ---------------------------------------------

// var pune_employees = employees.filter(function (item) {
//     return item.city === "Pune";
// });

// console.log(pune_employees);

// ---------------------------------------------

// var pune_employees = employees.filter((item) => {
//     return item.city === "Pune";
// });

// console.log(pune_employees);

// ---------------------------------------------

var pune_employees = employees.filter(item => item.city === "Pune");
console.log(pune_employees);