// In TS, Function Parameters are required and you cannot extra arguments also
// const hello = function (name: string) {
//     console.log("Hello,", name);
// };

// hello("Manish");
// hello("Manish", "Sharma");   // Expected 1 arguments, but got 2
// hello();     // Expected 1 arguments, but got 0

// // ------------------------------------------ Optional Parameters (?)

// function Add(x?: number, y?: number): number {
//     x = x || 0;
//     y = y || 0
//     return x + y;
// }

// ------------------------------------------ Default Parameters

function Add(x = 0, y = 0): number {
    return x + y;
}

console.log(Add(2, 3));
console.log(Add(2));
console.log(Add());