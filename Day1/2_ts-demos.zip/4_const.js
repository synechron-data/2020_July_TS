var obj = { id: 1 };
console.log(obj);
obj.id = 100;
console.log(obj);
