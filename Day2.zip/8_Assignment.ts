function catchAll<T>(target: T, propertyKey: string, descriptor: any) {
    var originalMethod = descriptor.value;

    descriptor.value = function (...args: any[]) {
        try {
            var result = originalMethod.apply(this, args);
            return result;
        } catch (err) {
            console.log(err.message);
        }
    }

    return descriptor;
}

class DAL {
    @catchAll
    getCustomers() {
        throw new Error('Exception Thrown!!!');
    }
}

var dObject = new DAL();
dObject.getCustomers();