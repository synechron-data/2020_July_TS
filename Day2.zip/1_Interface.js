var s1 = { height: 10, width: 20 };
console.log(s1);
